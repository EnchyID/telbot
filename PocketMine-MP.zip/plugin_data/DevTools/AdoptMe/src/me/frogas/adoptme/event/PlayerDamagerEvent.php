<?php

namespace me\frogas\adoptme\event;

use pocketmine\Player;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\level\particle\HeartParticle;
use pocketmine\math\Vector3;
use pocketmine\item\{Food, Item, ItemFactory};
use me\frogas\adoptme\AdoptMe;

class PlayerDamagerEvent implements Listener {
	
	private $plugin;
	
	public function __construct(AdoptMe $plugin){
		$this->plugin = $plugin;
	}
	
	public function getLoader() : AdoptMe {
		return $this->plugin;
    }
	
	public function onPlayerDamagerEvent(EntityDamageByEntityEvent $event){
		$baby = $event->getEntity();
		$player = $event->getDamager();
		if($baby instanceof Player and $player instanceof Player){
			if(!$this->getLoader()->getDamagerSetting($player->getName(), $baby->getName()) == true){
				$event->setCancelled(true);
				return true;
			}
			$hand = $player->getInventory()->getItemInHand();
		    if($hand instanceof Food){
			    if($this->getLoader()->getBabyOwner($baby->getName(), $player->getName())){
				    $this->getLoader()->setAdoptExp($player->getName(), $baby->getName());
				    $this->removeItem($player, ItemFactory::get($hand->getId(), $hand->getDamage(), 1));
		            $baby->setScoreTag(TF::GRAY . "Lvl." . TF::AQUA . $this->getLoader()->getAdoptLevel($player->getName(), $baby->getName()) . TF::GRAY . " (" . TF::YELLOW . $this->getLoader()->getAdoptExp($player->getName(), $baby->getName()) . TF::GRAY . "%) Adopt by " . TF::RED . $player->getName());
		            if($baby->getFood() == 20){
			            $player->sendMessage($this->getLoader()->getPrefix() . $baby->getName() . " > I was not hungry dont gave me food many.");
			        }else{
		                $baby->setFood($baby->getFood() + 1);
		            }
		            if($this->getLoader()->getAdoptExp($player->getName(), $baby->getName()) == 10){
			            $this->getLoader()->setAdoptLevel($player->getName(), $baby->getName());
			            $this->getLoader()->setBabyExp($baby->getName(), $player->getName());
			            $player->addTitle(TF::GREEN . "Next level baby " . $this->getLoader()->getAdoptLevel($player->getName(), $baby->getName()), "Your baby " . $baby->getName() . " has next level");
			            $this->getLoader()->resetAdoptExp($player->getName(), $baby->getName());
			            if($this->getLoader()->getBabyExp($baby->getName(), $player->getName()) == 15){
				            $this->getLoader()->setBabyLevel($baby->getName(), $player->getName());
				            $player->addTitle(TF::GREEN . "Your next level to " . $this->getLoader()->getBabyLevel($baby->getName(), $player->getName()), "New level for you");
				            $this->getLoader()->resetBabyExp($baby->getName(), $player->getName());
				        }
		            }
		            if($this->getLoader()->getAdoptLevel($player->getName(), $baby->getName()) == 15){
			            $this->getLoader()->setAdoptScale($player->getName(), $baby->getName());
				        $baby->setScale(1);
			        }
			        $baby->getLevel()->addParticle(new HeartParticle(new Vector3($baby->getX(), $baby->getY() + 2, $baby->getZ()), 4));
			    }
			}
		}
	}
	
	public function removeItem(Player $player, $item){
		$getcount = $item->getCount();
		if($getcount <= 0){
			return;
		}
		for($index = 0; $index < $player->getInventory()->getSize(); $index ++){
			$setitem = $player->getInventory()->getItem($index);
			if($item->getID() == $setitem->getID() and $item->getDamage() == $setitem->getDamage()){
				if($getcount >= $setitem->getCount()){
					$getcount -= $setitem->getCount();
					$player->getInventory()->setItem($index, ItemFactory::get(Item::AIR, 0, 1));
				}else{
                    if($getcount < $setitem->getCount()){
					    $player->getInventory()->setItem($index, ItemFactory::get($item->getID(), 0, $setitem->getCount() - $getcount));
					}
					break;
				}
			}
		}
	}
}