<?php

namespace me\frogas\CPSAspect;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as Color;
use me\frogas\CPSAspect\task\CPSAspectTask;

class CPSAspect extends PluginBase implements Listener {
	
	public function onEnable(){
		Server::getInstance()->getPluginManager()->registerEvents($this, $this);
		$this->getScheduler()->scheduleRepeatingTask(new CPSAspectTask($this), 5);
	}
	
	public function sendTask(){
		foreach(Server::getInstance()->getLevels() as $level){
			foreach($level->getEntities() as $player){
				if($player instanceof Player){
					$cps = Server::getInstance()->getPluginManager()->getPlugin("CPS");
					if($player->hasPermission("cpsaspect-message")){
					    if($cps->getClicks($player) == max(15)){
						    $player->sendMessage(Color::RED . $player->getName() . " CPS is " . $cps->getClicks($player) . "! (" . $player->getLevel()->getName() . ")");
						}
					}
				}
			}
		}
	}
}