<?php

namespace me\frogas\challenges;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\{Config, TextFormat as TF};
use pocketmine\command\{CommandSender, Command};
use pocketmine\form\api\{CustomForm, SimpleForm};
use pocketmine\form\MenuForm;
use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\player\PlayerJoinEvent;

class Challenges extends PluginBase implements Listener {
	
	public $quest;
	public $prefix = TF::AQUA . "[Challenges] " . TF::WHITE;
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveResource("quest_data.json");
		$this->saveResource("player_data.json");
		$this->quest_data = $this->getDataFolder() . "quest_data.json";
		$this->quest = json_decode(file_get_contents($this->quest_data), true);
		$this->player_data = $this->getDataFolder() . "player_data.json";
		$this->player = json_decode(file_get_contents($this->player_data), true);
	}
	
	public function save(){
		file_put_contents($this->quest_data, json_encode($this->quest));
		file_put_contents($this->player_data, json_encode($this->player));
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function getAllQuests(){
		$list = [];
		foreach(array_keys($this->quest["categories"]) as $category){
			$list[] = $category;
		}
		return $list;
	}
	
	public function setPlayerQuest(Player $player, int $id){
		$this->player["players"][$player->getName()] = $id;
		$this->save();
	}
	
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		if(!isset($this->player["players"][$player->getName()]) && !isset($this->player["durings"][$player->getName()])){
			$this->player["players"][$player->getName()] = 0;
			$this->player["durings"][$player->getName()] = 0;
			$this->player["complete"][$player->getName()] = [];
			$this->save();
			return true;
		}
	}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
	    if($cmd->getName() == "challenges"){
		    if($player instanceof Player){
			    if(!isset($args[0])){
				    $player->sendMessage($this->getPrefix() . "Unknown command! Try /challenges (add|remove).");
			        $this->sendManage($player);
			        return true;
			    }
			    if($args[0] == "add"){
				    if(!isset($args[1])){
				        $player->sendMessage($this->getPrefix() . "Usage /challenges add (name).");
			            return true;
			        }
			        $this->sendAddQuest($player, $args[1]);
			    }
			}
		}
		return true;
	}
	
	public function sendManage(Player $player){
		$text = "List data of the challenges" . TF::EOL;
		foreach($this->getAllQuests() as $quest){
			if(!isset($this->player["complete"][$player->getName()][$quest])){
			    $text .= "- " . $this->quest["categories"][$quest]["name"] . TF::EOL . " - ChallengeID: (#" . $quest . ")" . TF::EOL . " - Status: [STARTING]" . TF::EOL;
			}else{
				$text .= "- " . $this->quest["categories"][$quest]["name"] . TF::EOL . " - ChallengeID: (#" . $quest . ")" . TF::EOL . " - Status: [COMPLETE]" . TF::EOL;
			}
		}
		$button = [];
		if(count(array_keys($this->player["complete"][$player->getName()])) >= count(array_keys($this->quest["categories"]))){
		    $button[] = ["text" => "ALL COMPLETE"];
		}else{
			$button[] = ["text" => "ACCEPT"];
		}
		$form = new MenuForm("Challenges", $text, $button, function(Player $player, int $result) : void {
	        if($result == 0){
	            if(count(array_keys($this->player["complete"][$player->getName()])) >= count(array_keys($this->quest["categories"]))){
			        $player->sendMessage($this->getPrefix() . "You've has completed all quests.");
			        return;
			    }
		        $this->setPlayerQuest($player, 1);
		        $player->sendMessage($this->getPrefix() . " You've accepted this challenges! Starting in (#1) ChallengeID.");
            }
        });
        $player->sendForm($form);
	}
	
	public function sendAddQuest(Player $player, string $quest){
		$form = new CustomForm(function(Player $player, $result) use($quest){
			if($result === null){
				return true;
			}
			if($result[1] == 0){
				$this->addQuests($quest, "breakblock", $result[2], $result[3], $result[4]);
			}
			if($result[1] == 1){
				$this->addQuests($quest, "placeblock", $result[2], $result[3], $result[4]);
			}
			if($result[1] == 2){
				$this->addQuests($quest, "dropitem", $result[2], $result[3], $result[4]);
			}
			if(!is_numeric($result[2]) && !is_numeric($result[3]) && !is_numeric($result[4])){
				$this->sendAddQuest($player);
				return true;
			}
			if(!isset($result[2]) && !isset($result[3]) && !isset($result[4])){
				$this->sendAddQuest($player);
				return true;
			}
			$player->sendMessage($this->getPrefix() . $quest . " challenge has created.");
		});
		$form->setTitle("Add Challenges");
		$form->addLabel($quest . " made successfully! What is next?");
		$form->addDropdown("Type of quest:", ["BREAK EVENT", "PLACE EVENT", "DROP EVENT"]);
		$form->addInput("ID of items:");
		$form->addInput("Meta of items:", "", 0);
		$form->addInput("Count of during:");
		$form->sendToPlayer($player);
	}
	
	public function onBlockBreak(BlockBreakEvent $event){
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(!isset($this->quest["categories"][$this->player["players"][$player->getName()]])){
			return true;
		}
		if($this->quest["categories"][$this->player["players"][$player->getName()]]["type"] == "breakblock"){
			if(($block->getId() == $this->quest["categories"][$this->player["players"][$player->getName()]]["id"]) && ($block->getDamage() == $this->quest["categories"][$this->player["players"][$player->getName()]]["meta"])){
				$this->player["durings"][$player->getName()] = $this->player["durings"][$player->getName()] + 1;
				$this->save();
				if($this->player["durings"][$player->getName()] >= $this->quest["categories"][$this->player["players"][$player->getName()]]["count"]){
					$player->sendMessage($this->getPrefix() . "You've has completed " . $this->quest["categories"][$this->player["players"][$player->getName()]]["name"] . " quest.");
			        $this->player["complete"][$player->getName()][$this->player["players"][$player->getName()]] = true;
			        $this->setPlayerQuest($player, $this->player["players"][$player->getName()] + 1);
				    if(!isset($this->quest["categories"][$this->player["players"][$player->getName()]])){
				        $this->player["durings"][$player->getName()] = 0;
				        $this->save();
					    return true;
					}
					$this->player["durings"][$player->getName()] = 0;
				    $this->save();
				    $player->sendMessage(
			            TF::LIGHT_PURPLE . " +_______QUEST INFORMATION_______+" . TF::EOL .
                        TF::LIGHT_PURPLE . "| " . TF::AQUA . $this->quest["categories"][$this->player["players"][$player->getName()]]["name"] . TF::EOL . 
                        TF::LIGHT_PURPLE . "| " . TF::AQUA . " QuestID: " . TF::GREEN . "(#" . $this->player["players"][$player->getName()] . ")" . TF::EOL .
                        TF::LIGHT_PURPLE . " +_______QUEST INFORMATION_______+" . TF::EOL
                    );
			        if(count(array_keys($this->player["complete"][$player->getName()])) >= count(array_keys($this->quest["categories"]))){
			            $player->sendMessage($this->getPrefix() . "You've has completed all quests.");
				        $this->player["durings"][$player->getName()] = 0;
				        $this->save();
				        return true;
				    }
					return true;
				}
				return true;
			}
			return true;
		}
		return true;
	}
	
	public function onBlockPlace(BlockPlaceEvent $event){
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(!isset($this->quest["categories"][$this->player["players"][$player->getName()]])){
			return true;
		}
		if($this->quest["categories"][$this->player["players"][$player->getName()]]["type"] == "placeblock"){
			if(($block->getId() == $this->quest["categories"][$this->player["players"][$player->getName()]]["id"]) && ($block->getDamage() == $this->quest["categories"][$this->player["players"][$player->getName()]]["meta"])){
				$this->player["durings"][$player->getName()] = $this->player["durings"][$player->getName()] + 1;
				$this->save();
				if($this->player["durings"][$player->getName()] >= $this->quest["categories"][$this->player["players"][$player->getName()]]["count"]){
					$player->sendMessage($this->getPrefix() . "You've has completed " . $this->quest["categories"][$this->player["players"][$player->getName()]]["name"] . " quest.");
			        $this->player["complete"][$player->getName()][$this->player["players"][$player->getName()]] = true;
			        $this->setPlayerQuest($player, $this->player["players"][$player->getName()] + 1);
				    if(!isset($this->quest["categories"][$this->player["players"][$player->getName()]])){
				        $this->player["durings"][$player->getName()] = 0;
				        $this->save();
					    return true;
					}
					$this->player["durings"][$player->getName()] = 0;
				    $this->save();
				    $player->sendMessage(
			            TF::LIGHT_PURPLE . " +_______QUEST INFORMATION_______+" . TF::EOL .
                        TF::LIGHT_PURPLE . "| " . TF::AQUA . $this->quest["categories"][$this->player["players"][$player->getName()]]["name"] . TF::EOL . 
                        TF::LIGHT_PURPLE . "| " . TF::AQUA . " QuestID: " . TF::GREEN . "(#" . $this->player["players"][$player->getName()] . ")" . TF::EOL .
                        TF::LIGHT_PURPLE . " +_______QUEST INFORMATION_______+" . TF::EOL
                    );
                    $this->save();
			        if(count(array_keys($this->player["complete"][$player->getName()])) >= count(array_keys($this->quest["categories"]))){
			            $player->sendMessage($this->getPrefix() . "You've has completed all quests.");
				        $this->player["durings"][$player->getName()] = 0;
				        $this->save();
				        return true;
				    }
					return true;
				}
				return true;
			}
			return true;
		}
		return true;
	}
	
	public function addQuests(string $name, string $type, int $id, int $meta, int $count){
		$this->quest["categories"][count(array_keys($this->quest["categories"])) + 1] = [
		    "name" => $name,
		    "type" => $type,
		    "id" => (int) $id,
		    "meta" => (int) $meta,
		    "count" => (int) $count
		];
		$this->save();
	}
}