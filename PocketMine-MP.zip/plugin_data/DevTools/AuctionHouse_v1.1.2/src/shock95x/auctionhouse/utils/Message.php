<?php

namespace shock95x\auctionhouse\utils;


class Message {

	// TODO

}