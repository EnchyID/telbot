<?php
namespace shock95x\auctionhouse\database;

class Query {

	const INIT = "auctionhouse.init";
	const INSERT = "auctionhouse.insert";
	const DELETE = "auctionhouse.delete";
	const FETCH_ALL = "auctionhouse.fetch.all";
}