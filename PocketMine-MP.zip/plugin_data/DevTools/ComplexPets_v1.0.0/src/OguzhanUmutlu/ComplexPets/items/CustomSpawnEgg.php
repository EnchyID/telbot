<?php

namespace OguzhanUmutlu\ComplexPets\items;

use OguzhanUmutlu\ComplexPets\ComplexPets;
use pocketmine\block\Block;
use pocketmine\entity\Entity;
use pocketmine\item\SpawnEgg;
use pocketmine\math\Vector3;
use pocketmine\Player;

class CustomSpawnEgg extends SpawnEgg {
    public function onActivate(Player $player, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector): bool {
        $nbt = Entity::createBaseNBT($blockReplace->add(0.5, 0, 0.5), null, lcg_value() * 360, 0);
        if($this->getNamedTag()->hasTag("petType")) {
            $petCount = 0;
            foreach(ComplexPets::getPetsSpawned() as $pet)
                if($pet->owner == $player->getName())
                    $petCount++;
            if($petCount >= ComplexPets::$conf["pet-limit-per-player"]) {
                $player->sendMessage("§c> You reached the pet limit!");
                return true;
            }
            $nbt->setString("petName", $this->getNamedTag()->getString("petName", "Pet"));
            $nbt->setString("petOwner", $player->getName());
            $entity = Entity::createEntity($this->getNamedTag()->getString("petType", "null"), $player->getLevelNonNull(), $nbt);
        } else {
            if($this->hasCustomName())
                $nbt->setString("CustomName", $this->getCustomName());
            $entity = Entity::createEntity($this->meta, $player->getLevelNonNull(), $nbt);
        }
        if($entity instanceof Entity) {
            $this->pop();
            $entity->spawnToAll();
            return true;
        }
        return false;
    }
}