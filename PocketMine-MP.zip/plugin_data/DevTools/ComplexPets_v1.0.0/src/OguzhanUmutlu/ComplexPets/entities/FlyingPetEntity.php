<?php

namespace OguzhanUmutlu\ComplexPets\entities;

use OguzhanUmutlu\ComplexPets\async\ScanRightWayTask;
use pocketmine\block\Solid;
use pocketmine\math\Vector3;
use pocketmine\Server;

abstract class FlyingPetEntity extends PetEntity {
    public $rightWays = [];
    public $passing = null;
    public $scanning = false;
    protected $gravity = 0.0;
    public function moveToOwner(): void {
        if($this->scanning) return;
        $direction = $this->getDirectionVector()->multiply($this->isUnderwater() ? 0.1 : 0.2);
        $firstBlock = $this->getTargetBlockCopy($this->yaw, 0, 0.5, 1.5);
        if((new Vector3($this->x, 0, $this->z))->distance(new Vector3($this->getOwner()->x, 0, $this->getOwner()->z)) > 1.8)
            $this->move($direction->x, 0, $direction->z);
        if($firstBlock instanceof Solid) {
            if($this->passing && isset($this->rightWays[$this->passing])) {
                $this->onWay();
            } else {
                $this->scanning = true;
                Server::getInstance()->getAsyncPool()->submitTask(new ScanRightWayTask(
                    $this->level->getChunk($firstBlock->x >> 4, $firstBlock->z >> 4)->fastSerialize(),
                    $firstBlock->x,
                    $firstBlock->y,
                    $firstBlock->z,
                    $this->level->getId(),
                    $this->id
                ));
            }
            return;
        } else if($this->passing) {
            $way = $this->rightWays[$this->passing] ?? null;
            if($way == "down")
                $this->teleport($this->add(0, -0.5));
            else
                $this->teleport($this->add(0, 0.5));
            $this->passing = null;
            unset($this->rightWays[$this->passing]);
        }
        if(abs($this->getOwner()->y-$this->y) > 0.3)
            $this->setMotion(new Vector3(0, $this->getOwner()->y > $this->y ? 0.2 : -0.2, 0));
    }
    public function onWay(): void {
        $way = $this->rightWays[$this->passing] ?? null;
        if(!$way) return;
        if($way == "down")
            $this->setMotion(new Vector3(0, -0.3));
        else
            $this->setMotion(new Vector3(0, 0.3));
    }
    protected function applyGravity(): void {}
}