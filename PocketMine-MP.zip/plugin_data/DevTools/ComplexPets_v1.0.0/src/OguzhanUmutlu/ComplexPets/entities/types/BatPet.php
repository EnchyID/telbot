<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\FlyingPetEntity;

class BatPet extends FlyingPetEntity {
    public const NETWORK_ID = self::BAT;
    public $riderHeight = 0.5;
    protected function initEntity(): void {
        $this->setTamed();
        parent::initEntity();
    }

    public function getName(): string {
        return "BatPet";
    }
}
