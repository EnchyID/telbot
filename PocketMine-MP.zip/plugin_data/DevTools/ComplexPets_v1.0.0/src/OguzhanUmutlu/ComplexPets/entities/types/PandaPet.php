<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\PetEntity;
use pocketmine\Player;

class PandaPet extends PetEntity {
    public const NETWORK_ID = self::PANDA;
    public $petWidth = 1.0;
    public $petHeight = 1.0;
    public $riderHeight = 1.5;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function onRiderMount(Player $entity): void {
        parent::onRiderMount($entity);
    }

    public function getName(): string {
        return "PandaPet";
    }
}