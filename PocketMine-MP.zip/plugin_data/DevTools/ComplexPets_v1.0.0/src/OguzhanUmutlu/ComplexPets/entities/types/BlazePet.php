<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\FlyingPetEntity;
use pocketmine\Player;

class BlazePet extends FlyingPetEntity {
    public const NETWORK_ID = self::BLAZE;
    public $height = 1.5;
    public $petWidth = 1.0;
    public $petHeight = 1.0;
    public $riderHeight = 2;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function onRiderMount(Player $entity): void {
        parent::onRiderMount($entity);
    }

    public function getName(): string {
        return "BlazePet";
    }
}