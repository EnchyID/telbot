<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\FlyingPetEntity;
use pocketmine\Player;

class GhastPet extends FlyingPetEntity {
    public const NETWORK_ID = self::GHAST;
    public $width = 4.2;
    public $height = 4.2;
    public $petWidth = 4.0;
    public $petHeight = 4.0;
    public $riderHeight = 4.5;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function onRiderMount(Player $entity): void {
        parent::onRiderMount($entity);
    }

    public function getName(): string {
        return "GhastPet";
    }
}