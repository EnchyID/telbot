<?php

namespace OguzhanUmutlu\ComplexPets\async;

use OguzhanUmutlu\ComplexPets\entities\FlyingPetEntity;
use pocketmine\level\format\Chunk;
use pocketmine\level\Level;
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;

class ScanRightWayTask extends AsyncTask {
    public $chunk = "";
    public $x = 1;
    public $y = 1;
    public $z = 1;
    public $levelId = 1;
    public $entityId = 1;
    public function __construct(string $chunk, int $x, int $y, int $z, int $levelId, int $entityId) {
        $this->chunk = $chunk;
        $this->x = $x;
        $this->y = $y;
        $this->z = $z;
        $this->levelId = $levelId;
        $this->entityId = $entityId;
    }

    public function onRun() {
        $chunk = Chunk::fastDeserialize($this->chunk);
        $x = $this->x & 0x0f;
        $y = $this->y;
        $z = $this->z & 0x0f;
        $upFirst = null;
        $downFirst = null;
        for($l=$y;$l>0;$l--)
            if($chunk->getBlockId($x, $l, $z) == 0 && $downFirst == null)
                $downFirst = $l;
        for($l=$y;$l<256;$l++)
            if($chunk->getBlockId($x, $l, $z) == 0 && $upFirst == null)
                $upFirst = $l;
        if($upFirst == null && $downFirst == null) return;
        if(!$upFirst) {
            $this->setResult("down");
            return;
        }
        if(!$downFirst) {
            $this->setResult("up");
            return;
        }
        $dl = abs($downFirst-$y);
        $ul = abs($upFirst-$y);
        $this->setResult($dl < $ul ? "down" : "up");
    }

    public function onCompletion(Server $server) {
        $level = $server->getLevel($this->levelId);
        if(!$level instanceof Level) return;
        $entity = $level->getEntity($this->entityId);
        if(!$entity instanceof FlyingPetEntity) return;
        if(!$this->hasResult()) {
            $entity->scanning = false;
            return;
        }
        $way = $this->getResult();
        $entity->scanning = false;
        $entity->passing = $this->x.".".$this->z;
        $entity->rightWays[$entity->passing] = $way;
    }
}