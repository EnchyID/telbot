<?php

namespace muqsit\chestshop\Sound;

use pocketmine\level\sound\Sound;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;

class ChestClose extends Sound{

    public function encode() : PlaySoundPacket{
        $pk = new PlaySoundPacket();
        $pk->soundName = "random.chestclosed";
        $pk->x = $this->x;
        $pk->y = $this->y;
        $pk->z = $this->z;
        $pk->volume = 400;
        $pk->pitch = 1;
        return $pk;
    }
}