<?php

namespace me\frogas\clearinv;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\command\{CommandSender, Command};

class ClearINV extends PluginBase implements Listener {
	
	public $prefix = TF::RED . "[CLEARINV] " . TF::WHITE;
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		if($cmd->getName() == "clear"){
			if($player instanceof Player){
				if(!isset($args[0])){
					$player->sendMessage($this->getPrefix() . "Usage /clear (all|hand)");
					return true;
				}
				if($args[0] == "all"){
			        if($player->hasPermission("clearinv.command.all")){
				        $player->getInventory()->clearAll();
				        $player->sendMessage($this->getPrefix() . "Your all in inventory has clear!");
				    }else{
					    $player->sendMessage(TF::RED . "clear-all.message.no-permission");
					}
				}
				if($args[0] == "hand"){
					if($player->hasPermission("clearinv.command.hand")){
				        $player->getInventory()->removeItem($player->getInventory()->getItemInHand());
				        $player->sendMessage($this->getPrefix() . "Your item in hand has clear!");
				    }else{
					    $player->sendMessage(TF::RED . "clear-all.message.no-permission");
					}
				}
			}
		}
		return true;
	}
}