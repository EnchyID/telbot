<?php

declare(strict_types = 1);

namespace BlockHorizons\BlockPets\pets\datastorage;

class MySQLDataStorer extends SQLDataStorer {
}