<?php

namespace me\frogas\custombackpack;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\Config;
use pocketmine\command\{CommandSender, Command};
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\ItemFactory;
use pocketmine\item\Item;
use me\frogas\custombackpack\muqsit\invmenu\{InvMenu, InvMenuHandler};
use jojoe77777\FormAPI\{CustomForm, SimpleForm};
use onebone\economyapi\EconomyAPI;

class CustomBackpack extends PluginBase implements Listener {
	
	public $prefix = "[Backpack] > ";
	public $backpack, $slot;
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->gui = InvMenu::create(InvMenu::TYPE_CHEST);
		$this->data = new Config($this->getDataFolder() . "backpacks.yml", Config::YAML);
		$this->data_slot = new Config($this->getDataFolder() . "slots.yml", Config::YAML);
		$this->backpack = $this->data->getAll();
		$this->slot = $this->data_slot->getAll();
		if(!InvMenuHandler::isRegistered()){
			InvMenuHandler::register($this);
		}
	}
	
	public function save(){
		$this->data->setAll($this->backpack);
		$this->data_slot->setAll($this->slot);
		$this->data->save();
		$this->data_slot->save();
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function getMyInven(Player $player){
        $list = [];
        foreach($player->getInventory()->getContents() as $key => $item){
        	$list[] = $item->getName();
        }
        return $list;
    }
    
    public function addToBackpack(Player $player, string $list, string $name, int $id, int $meta, int $count){
    	$this->backpack[$player->getName()][$name] = array(
            "itemName" => $list,
            "itemID" => $id,
            "itemMeta" => $meta,
            "itemCount" => $count
        );
        $this->save();
     }
     
     public function delFromBackpack(Player $player, string $name){
     	unset($this->backpack[$player->getName()][$name]);
         $this->save();
     }
     
     public function addSlot(Player $player, string $slot){
     	$this->slot[$player->getName()]["slot"] = $slot;
         $this->save();
     }
     
     public function myMoney(Player $player){
		return EconomyAPI::getInstance()->myMoney($player);
	}
	
	public function addMoney(Player $player, int $amount){
		return EconomyAPI::getInstance()->addMoney($player, $amount);
	}
	
	public function reduceMoney(Player $player, int $amount){
		return EconomyAPI::getInstance()->reduceMoney($player, $amount);
	}
	
	public function getMoneyUnit(){
		return EconomyAPI::getInstance()->getMonetaryUnit();
	}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		switch($cmd->getName()){
			case "backpack":
			    if($player instanceof Player){
				    if(empty($args[0])){
					    $player->sendMessage($this->getPrefix() . "Usage /backpack [add|delete|open|shop]");
					    return true;
					}
					switch($args[0]){
						case "add":
						    $form = new CustomForm(function(Player $player, $data){
							    if(isset($data)){
			                        $all = $this->getMyInven($player);
			                        $list = $all[$data[0]];
								    if(empty($data[1] || $data[2])){
									    $player->sendMessage($this->getPrefix() . "Sweash input lenght");
									    return true;
									}
									$this->addToBackpack($player, $list, $data[1], $player->getInventory()->getItemInHand()->getId(), $player->getInventory()->getItemInHand()->getDamage(), $data[2]);
								}
							});
							$form->setTitle("Add Backpack");
							$form->addDropdown("Select item:", $this->getMyInven($player));
							$form->addInput("Enter name:", "", $player->getInventory()->getItemInHand()->getName());
							$form->addInput("Enter count:", "", $player->getInventory()->getItemInHand()->getCount());
							$form->sendToPlayer($player);
						break;
						case "delete":
						    $this->gui->readonly();
						    $this->gui->setListener([$this, "backpackDeleteListener"]);
						    $this->gui->setName($player->getName() . "'s backpack");
						    $inventory = $this->gui->getInventory();
						    if(isset($this->slot[$player->getName()])){
					            if(isset($this->backpack[$player->getName()])){
						            foreach(array_keys($this->backpack[$player->getName()]) as $name){
							            $inventory->addItem(Item::get($this->backpack[$player->getName()][$name]["itemID"], $this->backpack[$player->getName()][$name]["itemMeta"], $this->backpack[$player->getName()][$name]["itemCount"])->setCustomName($this->backpack[$player->getName()][$name]["itemName"]));
							            for($slot = $this->slot[$player->getName()]["slot"]; $slot <= 26;){
									        $inventory->setItem($slot, Item::get(160, 9, 1));
								        }
							        }
							    }
						    }
						    $this->gui->send($player);
						break;
						case "open":
						    $this->gui->readonly();
						    $this->gui->setListener([$this, "backpackListener"]);
						    $this->gui->setName($player->getName() . "'s backpack");
						    $inventory = $this->gui->getInventory();
						    if(isset($this->slot[$player->getName()])){
					            if(isset($this->backpack[$player->getName()])){
						            foreach(array_keys($this->backpack[$player->getName()]) as $name){
							            $inventory->addItem(Item::get($this->backpack[$player->getName()][$name]["itemID"], $this->backpack[$player->getName()][$name]["itemMeta"], $this->backpack[$player->getName()][$name]["itemCount"])->setCustomName($this->backpack[$player->getName()][$name]["itemName"]));
							            for($slot = $this->slot[$player->getName()]["slot"]; $slot <= 26;){
									        $inventory->setItem($slot, Item::get(160, 9, 1));
								        }
							        }
							    }
						    }
						    $this->gui->send($player);
						break;
						case "shop":
						    $form = new SimpleForm(function(Player $player, $data){
							    $result = $data;
							    if($result === null){
								    return true;
								}
								switch($result){
									case 0:
									    $money = $this->myMoney($player);
									    $price = 300000;
									    if($money >= $price){
										    $this->reduceMoney($player, $price);
										    $this->addSlot($player, 10);
										}else{
											$player->sendMessage($this->getPrefix() . "Your dont have money to buy slot");
										}
									break;
									case 1:
									    $money = $this->myMoney($player);
									    $price = 315000;
									    if($money >= $price){
										    $this->reduceMoney($player, $price);
										    $this->addSlot($player, 15);
										}else{
											$player->sendMessage($this->getPrefix() . "Your dont have money to buy slot");
										}
									break;
									case 2:
									    $money = $this->myMoney($player);
									    $price = 405000;
									    if($money >= $price){
										    $this->reduceMoney($player, $price);
										    $this->addSlot($player, 21);
										}else{
											$player->sendMessage($this->getPrefix() . "Your dont have money to buy slot");
										}
									break;
									case 3:
									    $money = $this->myMoney($player);
									    $price = 500000;
									    if($money >= $price){
										    $this->reduceMoney($player, $price);
										    $this->addSlot($player, 26);
										}else{
											$player->sendMessage($this->getPrefix() . "Your dont have money to buy slot");
										}
									break;
								}
							});
							$form->setTitle("Slot Shop");
							$form->setContent("Your money " . $this->myMoney($player) . " | Your slot " . $this->slot[$player->getName()]["slot"]);
							$form->addButton("§cSlot x10 §f> §a" . $this->getMoneyUnit() . "300000\n§7TAP TO BUY");
							$form->addButton("§cSlot x15 §f> §a" . $this->getMoneyUnit() . "315000\n§7TAP TO BUY");
							$form->addButton("§cSlot x21 §f> §a" . $this->getMoneyUnit() . "405000\n§7TAP TO BUY");
							$form->addButton("§cSlot x26 §f> §a" . $this->getMoneyUnit() . "500000\n§7TAP TO BUY");
							$form->sendToPlayer($player);
						break;
					}
				}else{
					$this->getServer()->getLogger()->info($this->getPrefix() . "Used commands on server.");
				}
			break;
		}
		return true;
	}
	
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$this->addSlot($player, 5);
	}
	
	public function backpackListener(Player $player, Item $item){
		$inventory = $this->gui->getInventory();
		foreach(array_keys($this->backpack[$player->getName()]) as $name){
			if($item->getCustomName() == $name){
				$player->sendMessage($this->getPrefix() . "You select " . $name);
				$player->removeWindow($inventory);
			}
		}
	}
	
	public function backpackDeleteListener(Player $player, Item $item){
		$inventory = $this->gui->getInventory();
		foreach(array_keys($this->backpack[$player->getName()]) as $name){
			if($item->getCustomName() == $name){
				$this->delFromBackpack($player, $name);
				$player->sendMessage($this->getPrefix() . "You unset " . $name);
				$player->removeWindow($inventory);
			}
		}
	}
}